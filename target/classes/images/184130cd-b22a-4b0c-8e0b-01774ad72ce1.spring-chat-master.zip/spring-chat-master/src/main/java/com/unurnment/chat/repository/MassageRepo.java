package com.unurnment.chat.repository;

import com.unurnment.chat.model.Massage;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface MassageRepo extends CrudRepository<Massage,Long>{
    List<Massage> findByTag(String tag);
}
